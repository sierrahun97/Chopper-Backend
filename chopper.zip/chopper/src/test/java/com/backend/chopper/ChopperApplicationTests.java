package com.backend.chopper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChopperApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.backend.chopper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChopperApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChopperApplication.class, args);
	}

}
